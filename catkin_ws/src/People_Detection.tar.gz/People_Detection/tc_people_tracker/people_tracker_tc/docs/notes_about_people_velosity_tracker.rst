Velocity Tracker
----------------


Topics of interest:

publish:
/people

/visualization_marker


subscriber:
/people_tracker_measurements

