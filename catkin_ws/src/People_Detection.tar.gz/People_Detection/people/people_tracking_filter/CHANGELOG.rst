^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package people_tracking_filter
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

1.0.9 (2015-09-01)
------------------
* Update CMakeLists.txt
* Contributors: David Lu!!

1.0.8 (2014-12-10)
------------------
* cleanup formatting with astyle (supersedes `#18 <https://github.com/wg-perception/people/issues/18>`_)
* Contributors: Dan Lazewatsky

1.0.4 (2014-07-09)
------------------
* merging people_tracking_filter into people
* Contributors: David Lu!!

1.0.3 (2014-03-01)
------------------

1.0.2 (2014-02-28)
------------------

1.0.1 (2014-02-27)
------------------
* people_tracking_filter --> people_experimental
  git-svn-id: https://code.ros.org/svn/wg-ros-pkg/trunk/stacks/people@40197 7275ad9f-c29b-430a-bdc5-66f4b3af1622
* Added platform tags for Ubuntu 9.04, 9.10, and 10.04.
  git-svn-id: https://code.ros.org/svn/wg-ros-pkg/trunk/stacks/people@36945 7275ad9f-c29b-430a-bdc5-66f4b3af1622
* Unblacklisting
  git-svn-id: https://code.ros.org/svn/wg-ros-pkg/trunk/stacks/people@33042 7275ad9f-c29b-430a-bdc5-66f4b3af1622
* temporarily removed dep on message_sequencing
  git-svn-id: https://code.ros.org/svn/wg-ros-pkg/trunk/stacks/people@33041 7275ad9f-c29b-430a-bdc5-66f4b3af1622
* more dependencies removed
  git-svn-id: https://code.ros.org/svn/wg-ros-pkg/trunk/stacks/people@32912 7275ad9f-c29b-430a-bdc5-66f4b3af1622
* git-svn-id: https://code.ros.org/svn/wg-ros-pkg/trunk/stacks/people@32909 7275ad9f-c29b-430a-bdc5-66f4b3af1622
* filter-->people_tracking_filter, follower-->person_follower
  git-svn-id: https://code.ros.org/svn/wg-ros-pkg/trunk/stacks/people@32896 7275ad9f-c29b-430a-bdc5-66f4b3af1622
* Contributors: Brian Gerkey, Caroline Pantofaru
